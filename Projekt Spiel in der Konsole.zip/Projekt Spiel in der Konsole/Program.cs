﻿
using Microsoft.Win32;
/// Code für Consolensteuerung
using System;
using System.IO;
using System.Net.NetworkInformation;
using System.Threading;
using System.Windows.Documents;



namespace ConsolenSteuerung
{


    internal class Program
    {
        static string[,] spielBrett = new string[25, 25];
        static bool[,] zielListe = new bool[25, 25];
        static bool running = true;
        static ConsoleKeyInfo inputkey;
        static ConsoleKey key;
        static int xKoorMaxl, yKoorMaxl;




      


        static void Eingabe()
        {


            while (running)
            {
                inputkey = Console.ReadKey(true);
                key = inputkey.Key;
            }

        }

        [STAThread]
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.CursorVisible = false;


            spielBrett = new string[100, 100];

            const int MAX_X = 30;
            const int MAX_Y = 30;

            //StartScreen();

            MenuAusgabe();

            // parallele Methode zum Einlesen des Tastendrucks
            var myThread = new System.Threading.Thread(Eingabe);
            myThread.Start();

            Console.SetWindowSize(MAX_X, MAX_Y);    // Konsolen Größe 
            Console.Title = "Konsolensteuerung von Julia Kegelreiter";

            



        }




        private static void StartScreen()
        {
            int runx = 0;

            Console.SetCursorPosition(5, 4);

            while (runx < 18)
            {

                Console.Write("🧱");                     //Zeile 1
                Thread.Sleep(5);
                runx++;

            }
            Console.WriteLine();


            KreuzAusgabe("🧱", 5, 5);


            BoxAusgabe(7, 5);

            KreuzAusgabe("🧱", 9, 5);

            Console.SetCursorPosition(11, 5);
            Console.ForegroundColor = ConsoleColor.Red;                             //Zeile 2
            Console.WriteLine('❌');
            Thread.Sleep(25);

            Console.ForegroundColor = ConsoleColor.White;

            KreuzAusgabe("🧱", 29, 5);

            KreuzAusgabe("🧱", 31, 5);
            KreuzAusgabe("🧱", 33, 5);


            Console.SetCursorPosition(5, 5);
            for (int i = 5; i < 15; i++)
            {
                Console.WriteLine("🧱");

                Console.SetCursorPosition(5, i);
                Thread.Sleep(5);

            }



            Console.SetCursorPosition(39, 5);
            for (int i = 5; i < 15; i++)
            {
                Console.WriteLine("🧱");

                Console.SetCursorPosition(39, i);
                Thread.Sleep(5);

            }



            KreuzAusgabe("🧱", 5, 6);

            KreuzAusgabe("🧱", 8, 6);

            Console.SetCursorPosition(10, 6);
            Console.ForegroundColor = ConsoleColor.Red;                             //Zeile 3
            Console.Write('O');
            Thread.Sleep(25);

            Console.ForegroundColor = ConsoleColor.White;

            KreuzAusgabe("🧱", 25, 6);

            KreuzAusgabe("🧱", 25, 6);

            KreuzAusgabe("🧱", 29, 6);

            KreuzAusgabe("🧱", 5, 7);

            KreuzAusgabe("🧱", 8, 7);







            BoxAusgabe(9, 7);

            Console.ForegroundColor = ConsoleColor.White;

            KreuzAusgabe("🧱", 30, 7);
            //Zeile 4
            KreuzAusgabe("🧱", 33, 7);
            KreuzAusgabe("🧱", 35, 7);

            BoxAusgabe(37, 7);

            




            KreuzAusgabe("🧱", 5, 8);

            KreuzAusgabe("🧱", 8, 8);

            KreuzAusgabe("🧱", 30, 8);                                //Zeile 5

           
            
           
            





            Console.SetCursorPosition(10, 12);

            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;

            KreuzAusgabe("____   ___  __  __ ___ ", 9, 9);
            KreuzAusgabe("|_ _) / _ \\ \\ \\/ /|_ _|", 9, 10);
            KreuzAusgabe("| _ \\ || ||  \\  /  | | ", 9, 11);
            KreuzAusgabe("||_)| ||_||  /  \\ _| |_", 9, 12);
            KreuzAusgabe("|___/ \\___/ /_/\\_\\|___|",9, 13);

            Console.BackgroundColor = ConsoleColor.Black;

            //Anschrift
            Thread.Sleep(25);
            Console.ForegroundColor = ConsoleColor.White;

          






            KreuzAusgabe("🧱", 5, 19);

            KreuzAusgabe("🧱", 8, 19);

            KreuzAusgabe("🧱", 30, 19);                                     //Zeile 18

            KreuzAusgabe("## ########", 33, 19);

            KreuzAusgabe("##############", 40, 19);

            Console.SetCursorPosition(52, 19);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write('O');
            Thread.Sleep(25);
            Console.ForegroundColor = ConsoleColor.White;

            KreuzAusgabe("######", 68, 19);

            KreuzAusgabe("🧱", 99, 19);




            Console.SetCursorPosition(78, 19);

            runx = 0;
            for (int straight = 5; straight < 15; straight++)
            {
                Console.Write('#');
                Thread.Sleep(10);                                               //mix Strecke nach unten
                runx++;
                Console.SetCursorPosition(78, straight);


            }




            KreuzAusgabe("🧱", 5, 20);

            KreuzAusgabe("🧱", 8, 20);

            KreuzAusgabe("🧱", 20, 20);                                 //Zeile 15

            KreuzAusgabe("## ## # ###", 30, 20);

            Console.SetCursorPosition(43, 20);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write('O');
            Thread.Sleep(25);
            Console.ForegroundColor = ConsoleColor.White;

            KreuzAusgabe("##########", 50, 20);

            KreuzAusgabe("######", 68, 20);

            Console.SetCursorPosition(10, 20);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write('O');
            Thread.Sleep(25);
            Console.ForegroundColor = ConsoleColor.White;

            KreuzAusgabe("🧱", 99, 20);




            KreuzAusgabe("🧱", 5, 21);


            BoxAusgabe(6, 21);

            Console.ForegroundColor = ConsoleColor.White;

            KreuzAusgabe("🧱", 30, 21);
            //Zeile 4
            KreuzAusgabe("## ######", 33, 21);                                         //Zeile 16

            BoxAusgabe(42, 21);

            KreuzAusgabe("🧱", 50, 21);

            KreuzAusgabe("########", 66, 21);

            KreuzAusgabe("### #########", 78, 21);

            KreuzAusgabe("🧱", 99, 21);

            Console.SetCursorPosition(5, 22);
           


            runx = 0;
            while (runx < 20)
            {                                                                   //Zeile 17
                Console.Write("🧱");
                Thread.Sleep(5);
                runx++;

            }

            Console.SetCursorPosition(5, 25);

            Console.Write("Press ENTER to continue...");

            Console.ReadKey(true);
            //Wartezeit

            Console.Clear();

        }

        static int KreuzAusgabe(string ausgabe, int xKoor, int yKoor)
        {
            Console.SetCursorPosition(xKoor, yKoor);
            Console.Write(ausgabe);
            Thread.Sleep(25);
            return 0;
        }

        static int BoxAusgabe(int xKoor, int yKoor)
        {
            Console.SetCursorPosition(xKoor, yKoor);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("📦");
            Thread.Sleep(25);
            Console.ForegroundColor = ConsoleColor.White;
            return 0;
        }

        private static void MenuAusgabe()
        {
            int aktiveZeile = 0;
            string[] zeilen = { "Spielerklärung", "Bestenliste", "Start" };
            Console.Clear();
          

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Menü (Abbruch mit 'Esc')");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Um sich im Menü nach oben zu bewegen,drücken Sie die Pfeiltaste nach oben");
            Console.WriteLine("Um sich im Menü nach unten zu bewegen,drücken Sie  die Pfeiltaste nach unten");

            Console.WriteLine();
            Console.SetCursorPosition(12, 0);
            while (true)
            {
                for (int i = 0; i < zeilen.Length; i++)
                {
                    if (i == aktiveZeile)
                    {
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                    }
                    else
                    {
                        Console.BackgroundColor = ConsoleColor.Black;
                    }
                    Console.SetCursorPosition(12, 6 + i);
                    Console.WriteLine(zeilen[i]);
                }
                key = Console.ReadKey(true).Key;

                switch (key)
                {
                    case ConsoleKey.UpArrow:
                        aktiveZeile--;
                        if (aktiveZeile < 0)
                        {
                            aktiveZeile += zeilen.Length;
                        }
                        break;
                    case ConsoleKey.DownArrow:
                        aktiveZeile++;
                        aktiveZeile %= zeilen.Length;
                        break;

                    case ConsoleKey.Enter:
                        switch (aktiveZeile)
                        {
                            case 0:
                                Console.Clear();
                                SpielErklärung();
                                break;


                            case 2:

                                Start();
                                break;


                        }
                        break;

                    case ConsoleKey.Escape:
                        Console.Clear();
                        Environment.Exit(0);
                        break;

                }
            }


            }

        

        private static void SpielErklärung()
        {

            Console.Clear();
            Console.WriteLine("Hallo, ich bin Sammy!");
            Console.WriteLine("Ich arbeite als Stapelfahrer am Hafen ");
            Console.WriteLine("Leider gab es einen Fehler bei der Platzierung von einigen Boxen");
            Console.WriteLine("Ich habe jetzt die Aufgabe bekommen die Boxen auf dem richtigen Platz zu bringen, damit es zu keiner Verwirrung kommt");
            Console.WriteLine("Ich brauche dafür deine Hilfe! Ich weiß nämlich nicht genau wo sich die Container befinden");
            Console.WriteLine("Mithilfe der Karte vom Hafen wirst du mir helfen sie auf ihren Platz zu fahren und zu platzieren");
            Console.WriteLine("Um mir zu sagen, dass ich nach oben gehen soll drücke die Pfeiltaste nach oben");
            Console.ReadLine();
        }








        private static void Start()
        {
            string level = "nothing";
            int aktiveZeile = 0;
            string[] zeilen = { "Level1", "Level2", "Level3" };

            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.SetCursorPosition(10, 0);

            ConsoleKey key = ConsoleKey.NoName;



            while (key != ConsoleKey.E)
            {
                for (int i = 0; i < zeilen.Length; i++)
                {
                    Console.BackgroundColor = (i == aktiveZeile) ? ConsoleColor.DarkRed : ConsoleColor.Black;
                    Console.SetCursorPosition(10, 4 + i);
                    Console.WriteLine(zeilen[i]);
                }

                Console.BackgroundColor = ConsoleColor.Black;

                key = Console.ReadKey(true).Key;

                switch (key)
                {
                    case ConsoleKey.UpArrow:
                        aktiveZeile = (aktiveZeile - 1 + zeilen.Length) % zeilen.Length;
                        break;

                    case ConsoleKey.DownArrow:
                        aktiveZeile = (aktiveZeile + 1) % zeilen.Length;
                        break;

                    case ConsoleKey.Enter:
                        level = zeilen[aktiveZeile] + ".txt";
                        Console.Clear();
                        break;
                    case ConsoleKey.Escape:
                        MenuAusgabe();
                        break;
                }

                if (key == ConsoleKey.Enter)
                    break;
            }

            BoardInitialize(level);

            DrawBoard();

        }

        static void BoardInitialize(string level)
        {
            var sr = new StreamReader(level);


            string zeile;

            for (int i = 0; !sr.EndOfStream; i++)
            {
                zeile = sr.ReadLine();

                for (int j = 0; j < zeile.Length; j++)
                {

                    switch (zeile[j])
                    {
                        case '#':
                            spielBrett[j, i] = "Wand";
                            break;
                        case 'x':
                            spielBrett[j, i] = "Ziel";
                            zielListe[j, i] = true;
                            break;
                        case 'O':
                            spielBrett[j, i] = "Box";
                            break;
                        case '§':
                            spielBrett[j, i] = "Maxl";
                            xKoorMaxl = j;
                            yKoorMaxl = i;
                            break;
                        case ' ':
                            spielBrett[j, i] = "Leer";
                            break;
                        
                    }

                }
            }
        }

        static void DrawBoard()
        {
            Console.SetCursorPosition(0, 0);
 
            for (int x = 0; x < 25; x++)
            {
                if (spielBrett[x, 0] == null)
                { break; }
                for (int y = 0; y < 25; y++)
                {
                    string tile = spielBrett[y, x];

                    switch (tile)
                    {
                        case "Wand":
                            Console.Write("🧱");
                            break;
                        case "Box":
                            Console.Write("📦");
                            break;
                        case "BoxImZiel":
                            Console.Write("📦");
                            break;
                        case "Ziel":
                            Console.Write("❌");
                            break;
                        case "Maxl":
                            Console.Write("🧍‍♀️");
                            break;
                        case "Leer":
                            if (zielListe[y, x] == true)
                            {
                                Console.Write("❌");
                            }
                            else
                            {
                                Console.Write("  ");
                            }
                            break;
                    }
                }
                Console.WriteLine();
            }
            Movement();
        }


        static void Movement()
        {

            //key = Console.ReadKey(true).Key;


            while (true)
            {
                if (Console.KeyAvailable)
                {
                    ConsoleKeyInfo key = Console.ReadKey(true);


                    switch (key.Key)
                    {
                        case ConsoleKey.UpArrow:
                            if (spielBrett[xKoorMaxl, yKoorMaxl - 1] == "Leer" || spielBrett[xKoorMaxl, yKoorMaxl - 1] == "Ziel")
                            {
                                spielBrett[xKoorMaxl, yKoorMaxl - 1] = "Maxl";
                                spielBrett[xKoorMaxl, yKoorMaxl] = "Leer";

                                yKoorMaxl--;

                            }
                            else if (spielBrett[xKoorMaxl, yKoorMaxl - 1] == "Box")
                            {
                                if (spielBrett[xKoorMaxl, yKoorMaxl - 2] == "Leer" || spielBrett[xKoorMaxl, yKoorMaxl - 2] == "Ziel")
                                {
                                    spielBrett[xKoorMaxl, yKoorMaxl - 1] = "Maxl";
                                    spielBrett[xKoorMaxl, yKoorMaxl - 2] = "Box";
                                    spielBrett[xKoorMaxl, yKoorMaxl] = "Leer";

                                    yKoorMaxl--;
                                }
                            }
                            DrawBoard();
                            Console.WriteLine("nach oben");
                            break;

                        case ConsoleKey.DownArrow:
                            if (spielBrett[xKoorMaxl, yKoorMaxl + 1] == "Leer" || spielBrett[xKoorMaxl, yKoorMaxl + 1] == "Ziel")
                            {
                                spielBrett[xKoorMaxl, yKoorMaxl + 1] = "Maxl";
                                spielBrett[xKoorMaxl, yKoorMaxl] = "Leer";
                                yKoorMaxl++;
                            }
                            else if (spielBrett[xKoorMaxl, yKoorMaxl + 1] == "Box")
                            {
                                if (spielBrett[xKoorMaxl, yKoorMaxl + 2] == "Leer" || spielBrett[xKoorMaxl, yKoorMaxl + 2] == "Ziel")
                                {
                                    spielBrett[xKoorMaxl, yKoorMaxl + 1] = "Maxl";
                                    spielBrett[xKoorMaxl, yKoorMaxl + 2] = "Box";
                                    spielBrett[xKoorMaxl, yKoorMaxl] = "Leer";
                                    yKoorMaxl++;
                                }
                            }
                            DrawBoard();
                            Console.WriteLine("nach unten");
                            break;

                        case ConsoleKey.LeftArrow:
                            if (spielBrett[xKoorMaxl - 1, yKoorMaxl] == "Leer" || spielBrett[xKoorMaxl - 1, yKoorMaxl] == "Ziel")
                            {
                                spielBrett[xKoorMaxl - 1, yKoorMaxl] = "Maxl";
                                spielBrett[xKoorMaxl, yKoorMaxl] = "Leer";
                                xKoorMaxl--;
                            }
                            else if (spielBrett[xKoorMaxl - 1, yKoorMaxl] == "Box")
                            {
                                if (spielBrett[xKoorMaxl - 2, yKoorMaxl] == "Leer" || spielBrett[xKoorMaxl - 2, yKoorMaxl] == "Ziel")
                                {
                                    spielBrett[xKoorMaxl - 1, yKoorMaxl] = "Maxl";
                                    spielBrett[xKoorMaxl - 2, yKoorMaxl] = "Box";
                                    spielBrett[xKoorMaxl, yKoorMaxl] = "Leer";
                                    xKoorMaxl--;
                                }

                            }
                           
                            DrawBoard();
                            Console.WriteLine("nach links");
                            break;

                        case ConsoleKey.RightArrow:
                            if (spielBrett[xKoorMaxl + 1, yKoorMaxl] == "Leer" || spielBrett[xKoorMaxl + 1, yKoorMaxl] == "Ziel")
                            {
                                spielBrett[xKoorMaxl + 1, yKoorMaxl] = "Maxl";
                                spielBrett[xKoorMaxl, yKoorMaxl] = "Leer";
                                xKoorMaxl++;
                            }
                            else if (spielBrett[xKoorMaxl + 1, yKoorMaxl] == "Box")
                            {
                                if (spielBrett[xKoorMaxl + 2, yKoorMaxl] == "Leer" || spielBrett[xKoorMaxl + 2, yKoorMaxl] == "Ziel")
                                {
                                    spielBrett[xKoorMaxl + 1, yKoorMaxl] = "Maxl";
                                    spielBrett[xKoorMaxl + 2, yKoorMaxl] = "Box";
                                    spielBrett[xKoorMaxl, yKoorMaxl] = "Leer";
                                    xKoorMaxl++;
                                }
                            }

                            DrawBoard();
                            Console.WriteLine("nach rechts");
                            break;

                        case ConsoleKey.Escape:
                            Start();
                            break;
                    }
                }

                Thread.Sleep(10); 
            }

        }

    }
}
